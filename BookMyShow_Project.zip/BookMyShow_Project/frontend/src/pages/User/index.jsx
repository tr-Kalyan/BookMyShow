import React from 'react'
import Booking from './Booking'

function User() {
  return (
    <div>
      <Booking/>
    </div>
  )
}

export default User